void P1600Message(void); // prototype
unsigned int SumSeries(unsigned int start,unsigned int end,unsigned int increment);

