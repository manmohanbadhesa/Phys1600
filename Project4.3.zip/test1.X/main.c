#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "putty.h"
#include "myUART.h"
#include <ctype.h>
#include "buttons.h"

#include "mcc_generated_files/mcc.h"

/*
                         Main application
 */
void buttonResponse(void);
unsigned int counter = 0, has_switch1_changed = 0;
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    clearPuTTY();
    
    unsigned int n = 0, m = 0, counter = 0, has_switch1_changed = 0,n1,m1;
    float T, f;
    
    // Intial value for blinking timers
    unsigned int j=45536;
    
    // Initial values for Ambulance timers of 0.4 and 0.6 seconds:
    unsigned int k=15536,h=28036;
    
    // Is also changed inside switch loop for the required time
    T0CON1bits.CKPS = 2;   // N = 2^n, n < 16
    T0CON0bits.OUTPS = 0;  // M = m + 1, m < 16
    
    
    // just to see calculate the time period
    n = T0CON1bits.CKPS;   
    m = T0CON0bits.OUTPS;
    T = ((m+1.0)*65536.0 - j)*pow(2.0,n)*4.0/ _XTAL_FREQ;
    printf("RD2 On Time %f\n\n\r",T);
    
    
    //Duty cycle value stored in SFRs PWMxDCH:PWMxDCL  (or PWM5_INITIALIZE_DUTY_VALUE)
    printf("\n\rEasy Setup value of PWM5DC is %u  PR2 is %u\n\r", PWM5_INITIALIZE_DUTY_VALUE,PR2);
    //printf("%DC = %.1f \n\n\r", (float)PWM5_INITIALIZE_DUTY_VALUE*100.0/(PR2+1)/4.0);
    
    printf("\n\rEasy Setup value of PWM6DC is %u  PR4 is %u\n\r", PWM6_INITIALIZE_DUTY_VALUE,PR4);
    //printf("%DC = %.1f \n\n\r", (float)PWM6_INITIALIZE_DUTY_VALUE*100.0/(PR4+1)/4.0);
    

    while (1)
    {
        // program beings with a buttonResponse function wrapped outside main at the bottom
        /*
        has_switch1_changed = poll_switch1_for_edges(button_RD1_GetValue());
        DELAY_milliseconds(10);
        if ( has_switch1_changed == 1 )
        {
            DELAY_milliseconds(10);
            counter++;
            if (counter > 9) counter = 1;
            printf("State = %u \n\r",counter);           
            
        }
        */
        buttonResponse();
        switch(counter)
        {
            case 1: 
                    
                    PWM5_LoadDutyValue(1000);
                    PWM6_LoadDutyValue(1000);
                    
                    break;
            case 2: 
                
                    PWM5_LoadDutyValue(150);
                    PWM6_LoadDutyValue(1023);
                    
                    break;
            case 3: 
                    PWM5_LoadDutyValue(1000);
                    PWM6_LoadDutyValue(1000);
                    //DELAY_milliseconds(100);
                    TMR0IF = 0;       // clear flag
                    TMR0_WriteTimer(j);
                    while(!TMR0IF);
                    PWM5_LoadDutyValue(0);
                    PWM6_LoadDutyValue(1000);
                    //DELAY_milliseconds(100);
                    TMR0IF = 0;       // clear flag
                    TMR0_WriteTimer(j);
                    while(!TMR0IF);
                    break;
            case 4: 
                    PWM5_LoadDutyValue(300);
                    PWM6_LoadDutyValue(900);
                    
                    break;
            case 5: T0CON1bits.CKPS = 4;
                    PWM5_LoadDutyValue(1000);
                    PWM6_LoadDutyValue(1000);
                    TMR0IF = 0;       // clear flag
                    TMR0_WriteTimer(k);
                    while(!TMR0IF);
                    buttonResponse();
                    T0CON1bits.CKPS = 5;
                    PWM5_LoadDutyValue(0);
                    PWM6_LoadDutyValue(0);                    
                    TMR0IF = 0;       // clear flag
                    TMR0_WriteTimer(h);
                    while(!TMR0IF);
                    buttonResponse();
                    break;
            case 6: T0CON1bits.CKPS = 2;
                    PWM5_LoadDutyValue(0);
                    PWM6_LoadDutyValue(1000);
                    //DELAY_milliseconds(100);
                    TMR0IF = 0;       // clear flag
                    TMR0_WriteTimer(j);
                    while(!TMR0IF);
                    buttonResponse();
                    PWM5_LoadDutyValue(0);
                    PWM6_LoadDutyValue(0);
                    //DELAY_milliseconds(100);
                    TMR0IF = 0;       // clear flag
                    TMR0_WriteTimer(j);
                    while(!TMR0IF);
                    buttonResponse();
                    break;
                    
                    break;
            case 7: PWM5_LoadDutyValue(1000);
                    PWM6_LoadDutyValue(450);
                    
                    break;
            case 8: PWM5_LoadDutyValue(1000);
                    PWM6_LoadDutyValue(1000);
                    break;
            case 9: PWM5_LoadDutyValue(0);
                    PWM6_LoadDutyValue(1000);
                    break;
        }
    }
}

void buttonResponse(void)
{
has_switch1_changed = poll_switch1_for_edges(button_RD1_GetValue());
        DELAY_milliseconds(10);
        if ( has_switch1_changed == 1 )
        {
            DELAY_milliseconds(10);
            counter++;
            if (counter > 9) counter = 1;
            printf("State = %u \n\r",counter);           
            
        }
}
/*
 End of File
 */ 
 