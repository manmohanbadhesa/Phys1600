// functions to help with PuTTY

void clearPuTTY(void);
