void wait_for_ENTER(void);
void ReadNUART2(char holds_string[], unsigned int length_N);
